package wa.was.rpm.events;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;

import org.bukkit.entity.Player;
import org.bukkit.entity.Minecart; 
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import wa.was.rpm.RocketPropelledMinecarts;
import wa.was.rpm.tasks.slowMinecarts;

public class minecartEvent implements Listener {
	
	public static FileConfiguration config;
	public static JavaPlugin plugin;
	public static Server server;
	public static double boostFactor;
	public static double maxSpeed;
	public static boolean isFirst = true;
	public static Vector baseVector;
	
	// Setup environment
	public minecartEvent() {
		config = RocketPropelledMinecarts.config;
		plugin = RocketPropelledMinecarts.plugin;
		server = plugin.getServer();
		boostFactor = config.getDouble("boost-factor");
		maxSpeed = config.getDouble("maximum-speed");
		if ( maxSpeed > 0.6 ) {
			throw new IllegalArgumentException("maximum-speed Invalid Value: Maximum speed must be lower than 0.6");
		}
	}
	
	@EventHandler(priority=EventPriority.HIGH)
	public void onPlayerUse(PlayerInteractEvent event){
	    Player p = event.getPlayer();
	    ItemStack i = getMainHand(p);
	    
	    // Is player in vehicle, and is that vehicle a minecart, and is the item held a basic firework rocket
	    if ( p.isInsideVehicle() ) {
	    	if ( p.getVehicle() instanceof Minecart ) {
	    		if ( i.getType() == Material.FIREWORK ) {
	    			FireworkMeta firework = (FireworkMeta) i.getItemMeta();   			
	    			if ( ! ( firework.hasEffects() ) ) {
	    			
		    			// Get the Minecart in question
						Minecart cart = (Minecart) p.getVehicle();
						
						// Is this the first run? If so get base speed... (Unreliable)
						if ( isFirst ) {
							baseVector = cart.getVelocity();
							// Set first run flag false
				    		isFirst = false;
						}
			    		
			    		// Set new speed
						cart.setMaxSpeed(maxSpeed);
						cart.setVelocity(cart.getVelocity().multiply(boostFactor));
						
						// Play rocket sound
						p.playSound(p.getLocation(),Sound.ENTITY_FIREWORK_LAUNCH, 1, 1);
						
						// Slow this entity [ WIP ]
						@SuppressWarnings("unused")
						BukkitTask task = new slowMinecarts(cart, baseVector).runTaskTimer(plugin, 0, 10);
	
		    			// Remove Item for non-creative user
		    			if ( p.getGameMode() != GameMode.CREATIVE ) {
		    				incrementalRemoveMainHand(p, i);
		    			}
		    			
		    			// Cancel normal firework launch
		    			event.setCancelled(true);
	    			
	    			}
	    			
	    		}
	    	}
	    }

	}
	
	// Get the item in main hand
	public ItemStack getMainHand(Player player) {
	    return player.getInventory().getItemInMainHand();
	}
	
	// Incrementally Remove from main hand
	public void incrementalRemoveMainHand(Player player, ItemStack item) {
		int amount = item.getAmount();
		if ( amount > 1 ) {
			amount--;
			item.setAmount(amount);
		} else {
			item = null;
		}
		player.getInventory().setItemInMainHand(item);
	}
	
}
