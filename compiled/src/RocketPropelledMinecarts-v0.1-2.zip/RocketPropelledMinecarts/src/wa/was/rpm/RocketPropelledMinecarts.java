package wa.was.rpm;

//Import Bukkit API & Utils
import org.bukkit.plugin.java.JavaPlugin;

import wa.was.rpm.events.minecartEvent;

import java.io.File;

import org.bukkit.configuration.file.FileConfiguration;

public class RocketPropelledMinecarts extends JavaPlugin {
	
	public static JavaPlugin plugin;
	public static FileConfiguration config;
	
	public RocketPropelledMinecarts() {
    	createConfig();
    	config = getConfig();
	}
	
    @Override
    public void onEnable() {
    	plugin = this;
    	getServer().getPluginManager().registerEvents(new minecartEvent(), plugin);
    }
    
    @Override
    public void onDisable() {
    	//...
    }
    
    private void createConfig() {
        try {
            if (!getDataFolder().exists()) {
                getDataFolder().mkdirs();
            }
            File file = new File(getDataFolder(), "config.yml");
            if (!file.exists()) {
                getLogger().info("[RPM] Config.yml not found, creating it for you!");
                saveDefaultConfig();
            } else {
                getLogger().info("[RPM] Config.yml found, loading!");
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

    }

}
