package wa.was.rpm.tasks;

import org.bukkit.entity.Minecart;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class slowMinecarts extends BukkitRunnable {
	
	public Vector baseVector;
	public Minecart cart;
	
	// Setup environment
	public slowMinecarts(Minecart cart, Vector baseVector) {
		this.cart = cart;
		this.baseVector = baseVector;
	}

	// Slow minecart task
    @Override
    public void run() {

    	Vector cv = cart.getVelocity();
    	System.out.print("Current minecart velocity: "+cv.toString());
    	Vector nv = new Vector(
    					(cv.getX() > baseVector.getX() ? cv.getX() - 0.0025 : baseVector.getX()),
    					(cv.getY() > baseVector.getY() ? cv.getY() - 0.0025 : baseVector.getY()),
    					(cv.getZ() > baseVector.getZ() ? cv.getZ() - 0.0025 : baseVector.getZ())
    			);
    	System.out.print("Setting minecart velocity to: "+nv);
    	cart.setVelocity(nv);
    	if ( nv == baseVector ) {
    		this.cancel();
    	}
		
	}
	

}
